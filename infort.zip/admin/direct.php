<!DOCTYPE html>
<html>
    <head>
        <title>Dialog Alert</title>
    </head>
    <body>
    <script>

    
        var yakin = alert("Request Anda Sedang Diproses");

        if (yakin) {
            window.location="login.php"; 
        } else {
            window.location="login.php";

        }
    </script> 
    </body>
</html> 