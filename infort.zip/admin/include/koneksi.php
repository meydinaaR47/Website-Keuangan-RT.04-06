<?php 

	$koneksi = new mysqli("localhost", "root", "","keuangan");

	$hostname="http://localhost/infort2/admin";
?>
